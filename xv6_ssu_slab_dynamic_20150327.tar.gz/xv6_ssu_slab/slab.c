#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"
#include <stdbool.h>

struct {
	struct spinlock lock;
	struct slab slab[NSLAB]; 
} stable;

int square(int num){
	int count=1;
	int i=0;
	for(i=0; i<num; i++){
		count *=2;
	}
	return count;
}

void slabinit(){
	/*reset stable*/
	struct slab *s;
	acquire(&stable.lock);

	int i=3;
	for(s=stable.slab; s<&stable.slab[NSLAB]; s++){
		s->size=square(i++);
		s->num_pages=1;
		s->num_free_objects=(4096/s->size);
		s->num_used_objects=0;
		s->num_objects_per_page=(4096/s->size);
		s->bitmap=kalloc(); //지금 받아올수있는 오브젝트들의 갯수만큼 비트가 있어야함 kalloc으로 한페이지 할당
		s->page[(s->num_pages-1)]=kalloc(); //초기에는 한개의 페이지만 할당 모자라면 
	}
	release(&stable.lock);
}

unsigned int resizecachepages(unsigned int n){
	unsigned count =0;

	if(n && !(n & (n-1)))
		return n;

	while(n!=0)
	{	
		n >>= 1;
		count += 1;
	}
	return 1 << count;
}

bool get_bit(char num, int i) {
    return ((num & (1 << i)) != 0);
}

char set_bit(char num, int i) {
	
    return num | (1 << i);
}

char clear_bit(char num, int i) {
    char mask = ~(1 << i);
    return num & mask;
}

char *kmalloc(int size){
	if(size>2048){
		return 0x00;
	}
	
	struct slab *s;
	acquire(&stable.lock);
	
	int count = resizecachepages(size);
	char* objects = 0x0000;
	bool disleft=false;
	for(s=stable.slab; s<&stable.slab[NSLAB]; s++){
		if(s->size == count){
			if(s->num_free_objects !=0){
				if(s->num_pages == 1)
					objects = s->page[(s->num_pages-1)] + s->num_used_objects * s->size;
				else{
					objects = s->page[(s->num_pages-1)] + (s->num_used_objects - ((s->num_pages-1) * s->num_objects_per_page)) * s->size;
//					cprintf("num_used_objects %d\n",(s->num_used_objects));
//					cprintf("num_pages-1 %d\n",(s->num_pages-1) );
//					cprintf("s->num_objects_per_page %d\n",( s->num_objects_per_page) );
				}
				s->num_used_objects++;
				s->num_free_objects -= 1;
				int i=0;
				for(i=0; i<s->num_objects_per_page * s->num_pages; i++){
					if(get_bit(*(s->bitmap), i)){
						char retval = set_bit(*(s->bitmap), i);
						*(s->bitmap) = retval;
						break;
					}
				}
			}
			else{
				s->num_pages++;
				s->num_free_objects +=(4096/s->size);
				s->page[(s->num_pages-1)]=kalloc();
				release(&stable.lock);
				objects=kmalloc(size);
				disleft=true;
			}
					
		}
	}
	if(!disleft)
		release(&stable.lock);
	return objects;
}

void kmfree(char *addr, int size){
	struct slab *s;
	int count = resizecachepages(size);
	acquire(&stable.lock);
	for(s=stable.slab; s<&stable.slab[NSLAB]; s++){
		if(s->size == count){
			for(int i=1; i<=s->num_pages; i++){
				for(int j = 0 ; j < s->num_objects_per_page ; j++){
					char *tmp = s->page[i - 1] + j * s->size;
					if(tmp == addr){
						clear_bit(*(s->bitmap), (i*s->num_objects_per_page + j));
						s->num_used_objects--;
						if(s->num_used_objects < (s->num_pages-1) * s->num_objects_per_page){
							kfree(s->page[(s->num_pages-1)]);
							s->num_pages--;
							s->num_free_objects -= s->num_objects_per_page;
						}
						s->num_free_objects++;
						release(&stable.lock);
						return ;
					}
				}
			}
		}
	}
	release(&stable.lock);
}

void slabdump(){
	cprintf("__slabdump__\n");

	struct slab *s;

	cprintf("size\tnum_pages\tused_objects\tfree_objects\n");

	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
		cprintf("%d\t%d\t\t%d\t\t%d\n", 
			s->size, s->num_pages, s->num_used_objects, s->num_free_objects);
	}
}
